//: statemachine:Input.java
// Inputs to a state machine
package statemachine;

public interface Input {} ///:~
