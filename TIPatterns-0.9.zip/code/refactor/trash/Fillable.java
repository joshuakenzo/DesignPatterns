//: refactor:trash:Fillable.java 
// Any object that can be filled with Trash.
package refactor.trash;

public interface Fillable { 
  void addTrash(Trash t); 
} ///:~
