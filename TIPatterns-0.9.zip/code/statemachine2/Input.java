//: statemachine2:Input.java
// Inputs to a state machine
package statemachine2;

public interface Input {} ///:~
