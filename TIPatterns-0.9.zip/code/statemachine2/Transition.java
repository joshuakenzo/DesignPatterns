//: statemachine2:Transition.java
// Transition function object for state machine
package statemachine2;

public interface Transition {
  void transition(Input i);
} ///:~
