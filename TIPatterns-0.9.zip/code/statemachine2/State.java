//: statemachine2:State.java
package statemachine2;

public class State {
  private String name;
  public State(String nm) { name = nm; }
  public String toString() { return name; }
} ///:~
