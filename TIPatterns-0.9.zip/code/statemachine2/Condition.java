//: statemachine2:Condition.java
// Condition function object for state machine
package statemachine2;

public interface Condition {
  boolean condition(Input i);
} ///:~
